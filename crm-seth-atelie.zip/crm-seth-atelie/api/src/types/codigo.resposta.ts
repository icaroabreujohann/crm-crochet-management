export interface CodigoResposta {
     mensagem: string,
     codigo: number
}