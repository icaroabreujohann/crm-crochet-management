import vuetify from 'eslint-config-vuetify'

rules: {
  'perfectionist/sort-imports': 'off'
}

export default vuetify()
