<template>
     <div style="height: 80vh;" class="d-flex align-center justify-center">
          <v-card class="pa-10 d-flex align-center justify-center flex-column" style="width: 25vw;">
               <v-img width="300px" class="no-border" src="/images/delete-dialog.png" />
               <h1 style="font-size: 6rem;">404</h1>
               <p>A página não existe</p>
          </v-card>
     </div>
</template>

<script setup lang="ts">
</script>