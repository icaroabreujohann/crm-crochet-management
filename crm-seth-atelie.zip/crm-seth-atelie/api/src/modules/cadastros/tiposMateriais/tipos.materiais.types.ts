export interface TipoMaterial {
     id: number,
     nome: string
}