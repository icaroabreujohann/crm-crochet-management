export interface UnidadeMedida {
     id: number,
     nome: string,
     sigla: string
}