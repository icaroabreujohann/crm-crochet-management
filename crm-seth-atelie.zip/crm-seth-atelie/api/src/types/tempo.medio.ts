export interface TempoMedio {
     horas: number,
     minutos: number
}