export const substituiPontoPorVirgula = (numero: number) => {
     return String(numero).replace('.',',')
}